License
=======

Click is licensed under a three-clause BSD License.  It basically means:
do whatever you want with it as long as the copyright in Click sticks
around, the conditions are not modified and the disclaimer is present.
Furthermore, you must not use the names of the authors to promote derivatives
of the software without written consent.

License Text
------------

.. include:: ../LICENSE
