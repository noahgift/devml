.. currentmodule:: click

.. include:: ../CHANGES
